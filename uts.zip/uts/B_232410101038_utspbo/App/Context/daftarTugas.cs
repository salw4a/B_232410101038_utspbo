﻿using B_232410101038_utspbo.Views;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace B_232410101038_utspbo.App.Context
{
    internal class daftarTugas
    {
        
        public static DataTable All()
        {
            string query = @"SELECT m.id,m.judul,m.deskripsi,m.deadline FROM Akun";
            DataTable daftarTugas = queryExecutor(query);
            return daftarTugas;
        }

        public static void AddTugas(M_daftarTugas tugasBaru)
        {
            string query = $"INSERT INTO {table} (judul, deskripsi, deadline) VALUES(@judul, @deskripsi, @deadline"; NpgsqlParameter[] parameters =
            {
                new NpgsqlParameter("@nama", tugasBaru.judul),
                new NpgsqlParameter("@nim", tugasBaru.deskripsi),
                new NpgsqlParameter("@email", tugasBaru.deadline),
            };
                commandExecutor(query, parameters);
        }


    }
}
