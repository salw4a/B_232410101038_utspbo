﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_232410101038_utspbo.App.Model
{
    internal class daftarTugas
    {
        [Key]
        public int id { get; set; }
        [Required]
        public string judul { get; set; }
        [Required]
        public string deskripsi { get; set; }
        [Required]
        public DateTime deadline { get; set; };
    }
}
