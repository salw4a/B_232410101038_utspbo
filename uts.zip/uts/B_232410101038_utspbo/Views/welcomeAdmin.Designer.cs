﻿namespace B_232410101038_utspbo.Views
{
    partial class welcomeAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblwelcome = new Label();
            button1 = new Button();
            label1 = new Label();
            checkBox1 = new CheckBox();
            button2 = new Button();
            SuspendLayout();
            // 
            // lblwelcome
            // 
            lblwelcome.AutoSize = true;
            lblwelcome.Font = new Font("Bookman Old Style", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblwelcome.ForeColor = Color.FromArgb(128, 128, 255);
            lblwelcome.Location = new Point(299, 103);
            lblwelcome.Name = "lblwelcome";
            lblwelcome.Size = new Size(178, 32);
            lblwelcome.TabIndex = 0;
            lblwelcome.Text = "WELCOME!";
            // 
            // button1
            // 
            button1.Font = new Font("Book Antiqua", 9F, FontStyle.Bold);
            button1.ForeColor = Color.FromArgb(128, 128, 255);
            button1.Location = new Point(326, 184);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 1;
            button1.Text = "Tugas";
            button1.UseVisualStyleBackColor = true;
            button1.Click += this.button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.ButtonFace;
            label1.Font = new Font("Book Antiqua", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(128, 128, 255);
            label1.Location = new Point(626, 407);
            label1.Name = "label1";
            label1.Size = new Size(76, 22);
            label1.TabIndex = 2;
            label1.Text = "Admin?";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(722, 408);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(22, 21);
            checkBox1.TabIndex = 3;
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Book Antiqua", 9F, FontStyle.Bold);
            button2.ForeColor = Color.FromArgb(128, 128, 255);
            button2.Location = new Point(292, 236);
            button2.Name = "button2";
            button2.Size = new Size(185, 34);
            button2.TabIndex = 4;
            button2.Text = "Daftar (Customer)";
            button2.UseVisualStyleBackColor = true;
            button2.Click += this.button2_Click;
            // 
            // welcomeAdmin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(checkBox1);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(lblwelcome);
            Name = "welcomeAdmin";
            Text = "dashboardAdmin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblwelcome;
        private Button button1;
        private Label label1;
        private CheckBox checkBox1;
        private Button button2;
    }
}